# -*- coding: utf-8 -*-
##############################################################################
#
#    Ali Husnain Arshad
#    Copyright (C) 2018-TODAY 
#    MNS UET(<https://www.alihusnain.ml>).
#
#
##############################################################################

from . import exam
from . import exam_attendees
from . import exam_room
from . import exam_session
from . import exam_type
from . import grade_configuration
from . import marksheet_line
from . import marksheet_register
from . import res_partner
from . import result_line
from . import result_template
