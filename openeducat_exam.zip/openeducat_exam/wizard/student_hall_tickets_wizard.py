# -*- coding: utf-8 -*-
###############################################################################
#
#    Ali Husnain Arshad
#    Copyright (C) 2018-TODAY 
#    MNS UET     (<https://www.alihusnain.ml>).
#
###############################################################################

from openerp import models, fields, api


class StudentHallTicket(models.TransientModel):

    """ Student Hall Ticket Wizard """
    _name = 'student.hall.ticket'

    exam_session_id = fields.Many2one(
        'op.exam.session', 'Exam Session', required=True)

    @api.multi
    def print_report(self):
        data = self.read(['exam_session_id'])[0]
        return self.env['report'].get_action(
            self, 'openeducat_exam.report_ticket', data=data)
