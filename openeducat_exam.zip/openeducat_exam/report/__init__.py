# -*- coding: utf-8 -*-

##############################################################################
#
#    Ali Husnain Arshad
#    Copyright (C) 2018-TODAY 
#    MNS UET(<https://www.alihusnain.ml>).
#
#
##############################################################################
#
###############################################################################

# from . import report_exam_student_lable
from . import student_hall_ticket_report
from . import student_marksheet
